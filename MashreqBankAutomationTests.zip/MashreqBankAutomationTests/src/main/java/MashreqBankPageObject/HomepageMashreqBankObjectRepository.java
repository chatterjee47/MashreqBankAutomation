package MashreqBankPageObject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class HomepageMashreqBankObjectRepository {
	public WebDriver driver;

	public HomepageMashreqBankObjectRepository(WebDriver driver) {
		this.driver = driver;
	}

	By Itemsdisplay = By.xpath("//div[@class='leftLinks']/ul/li");

	public void getItemsdisplay() throws InterruptedException {
		List<WebElement> Itemsdisplay = driver.findElements(
				By.xpath("//nav[@class='topNav ng-scope hidden-sm hidden-xs']/div/div/div[@class='leftLinks']/ul/li"));
		{
			System.out.println("Count of Items : " + Itemsdisplay.size());
		}

		for (int i = 0; i < Itemsdisplay.size(); i++) {
			System.out.println("Items display as :" + Itemsdisplay.get(i).getText());
			Thread.sleep(5000);
		}
	}

	By MashreqNews = By.xpath("//h3[contains(text(),'Mashreq News')]");

	public WebElement getMashreqNews() {
		return driver.findElement(MashreqNews);
	}

	public void getMashreqNewsdisplay() throws InterruptedException {
		List<WebElement> MashreqNewsDisplay = driver.findElements(By.xpath("//h3[contains(text(),'Mashreq News')]"));
		{
			System.out.println("Count of Items : " + MashreqNewsDisplay.size());
		}

		for (int i = 0; i < MashreqNewsDisplay.size(); i++) {
			System.out.println("Mashreq News Display as :" + MashreqNewsDisplay.get(i).getText());
			Thread.sleep(5000);
		}
	}

	public void ScrollDown(String numberone) throws InterruptedException {
		((JavascriptExecutor) driver).executeScript(numberone);
	}

	public void getScrollToMashreqNews() throws InterruptedException {
		WebElement ScrollToMashreqNews = driver.findElement(MashreqNews);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ScrollToMashreqNews);
		Thread.sleep(5000);
	}
	
	public void LoadTime() {
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
	
	public void WaitTillPageLoad() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		for (int i = 0; i < 100; i++) {
			try {
				Thread.sleep(1000);

			} catch (Exception e) {

			}
			if (js.executeScript("return document.readyState").toString().equals("complete")) {
				System.out.println("Page Loaded Completely");
				break;
			} else {
				System.out.println("Page is not Loaded Completely");
			}
		}
	}



	// div[@class='newsBox']
	By ScrollToContactUs = By.xpath("//h5[contains(text(),'Contact Us')]");
	By ContactUsLink = By.xpath("//p[contains(text(),'Call +9714 424 4444 Lost your card? Enquiries?')]");

	public void getScrollToContactUs() throws InterruptedException {
		WebElement ScrollToLBST = driver.findElement(ScrollToContactUs);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ScrollToLBST);
		Thread.sleep(5000);
	}

	By StatusTracker = By.xpath("//a[@class='btn btn-primary']");

	public void getScrollToStatusTracker() throws InterruptedException {
		WebElement ScrollToStatusTracker = driver.findElement(StatusTracker);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ScrollToStatusTracker);
		Thread.sleep(5000);
	}

	By Reachoutforproduct = By.xpath("//select[@id='reachoutforproduct']");

	public WebElement getreachoutforproduct() {
		return driver.findElement(Reachoutforproduct);
	}

	By ComplaintServiceInquiry = By.xpath("//select[@id='compInqServ']");

	public WebElement getComplaintServiceInquiry() {
		return driver.findElement(ComplaintServiceInquiry);
	}

	By ProductSelection = By.xpath("//select[@id='need']");

	public WebElement getProductSelection() {
		return driver.findElement(ProductSelection);
	}

	By SubProductSelection = By.xpath("//select[@id='product']");

	public WebElement getSubProductSelection() {
		return driver.findElement(SubProductSelection);
	}

	By MobileNumber = By.xpath("//input[@id='mobile']");

	public WebElement getMobileNumber() {
		return driver.findElement(MobileNumber);
	}

	By MobileNumberErrorMessage = By.xpath("//span[contains(text(),'Mobile number should be 7 digit')]");

	public WebElement getMobileNumberErrorMessage() {
		return driver.findElement(MobileNumberErrorMessage);
	}

	public void getReachoutforproduct() throws InterruptedException {
		Select selectoption = new Select(driver.findElement(Reachoutforproduct));
		System.out.println("Display all Options:  " + selectoption.getAllSelectedOptions());
		Thread.sleep(5000);
	}

	public void SelectDropdown(int enterindex, WebElement xpath) {
		Select select = new Select((xpath));
		select.selectByIndex(enterindex);
	}

	public WebElement getContactUsLink() {
		return driver.findElement(ContactUsLink);
	}

	By SubmitButton = By.xpath("//button[@id='btnSubmit']");

	public WebElement getSubmitButton() {
		return driver.findElement(SubmitButton);
	}

	By TextFieldValidation = By.xpath("//div[@class='col-lg-12 col-md-12 col-sm-12 col-xs-12 applyform']/div/div");

	public void getTextFieldValidation() throws InterruptedException {
		List<WebElement> TextFieldValidation = driver
				.findElements(By.xpath("//div[@class='col-lg-12 col-md-12 col-sm-12 col-xs-12 applyform']/div/div"));
		{
			System.out.println("Count of Items : " + TextFieldValidation.size());
		}

		for (int i = 0; i < TextFieldValidation.size(); i++) {
			System.out.println("Mashreq News Display as :" + TextFieldValidation.get(i).getText());
			Thread.sleep(5000);
		}
	}

	public static void highlightElement(WebDriver driver, WebElement ele) {
		try {
			for (int i = 0; i < 10; i++) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);", ele,
						"color: red; border: 2px solid red;");
			}
		} catch (Throwable t) {
			System.err.println("Error came : " + t.getMessage());
		}

	}
}
