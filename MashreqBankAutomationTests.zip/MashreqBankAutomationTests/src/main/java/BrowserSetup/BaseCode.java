package BrowserSetup;

import java.io.FileInputStream;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;







public class BaseCode 
{
	public static WebDriver driver;
	public static String MashreqBankUrl;
	
	public static String MPMurl;
	public static String TankReturns;
	
	public static Properties prop = new Properties();
	public static final String USERNAME = "";
	public static final String AUTOMATE_KEY = "";
	public static final String BROWSERSTACKURL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "";
	public static String experience; 
	

    public void waitForElement(WebDriver driver, int timeOutInSeconds, WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
		wait.until(ExpectedConditions.visibilityOf(element));
	}
    
    
   
    
	public synchronized static WebDriver initializeDriver(String browserNew, String execloc) throws Throwable
	{
		FileInputStream fis = new FileInputStream("util\\Variables.properties");
		prop.load(fis);
		String browser;
		String location;
		if (browserNew.equals("default"))
		{
		System.out.println("In default browser method");
		browser = prop.getProperty("browser");
		System.out.println("Browser in default method is"+browser);
		}
		
		else
		{
			browser=browserNew;
		}
		if (execloc.equals("default"))
		{
			System.out.println("In default exec location method");

			location = prop.getProperty("executionlocation");
			System.out.println("exec location in default method is"+location);

		}
		
		else
		{
			location=execloc;
		}
		//String location = prop.getProperty("executionlocation");
		
		experience=prop.getProperty("experience");
		String platform=prop.getProperty("mobile_platform");
		String iosversion=prop.getProperty("IOS_OSVERSION");
		String iosdevice=prop.getProperty("IOS_DEVICE");
		String androidversion=prop.getProperty("ADROID_OSVERSION");
		String androiddevice=prop.getProperty("ANDROID_DEVICE");
		MashreqBankUrl=prop.getProperty("MashreqBankUrl");
		DesiredCapabilities caps = new DesiredCapabilities();
		
		if(experience.equals("desktop"))
		{
			if(browser.equals("chrome"))
			{
				if(location.equals("local"))
				{
				System.out.println("in chrome method");
				//System.out.println(chrome_driver+"chrome drive path in chrome method");

			//	System.setProperty("webdriver.chrome.driver","src\\test\\resources\\drivers\\chromedriver.exe");
			//	driver = new ChromeDriver();
				
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--disable-notifications");
				System.setProperty("webdriver.chrome.driver","src\\test\\resources\\drivers\\chromedriver.exe");
				driver =new ChromeDriver(options);
				driver.manage().window().maximize();
				driver.manage().deleteAllCookies();
				driver.navigate().refresh();
				//driver=ThreadLocal.withInitial(() -> new ChromeDriver());
				//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				}
				
				else if(location.equals("grid"))
				{
					//System.out.println("Grid code");
					DesiredCapabilities dc = new DesiredCapabilities();
					dc.setBrowserName("chrome");
					dc.setPlatform(Platform.WIN10);	
					
					driver = new RemoteWebDriver(new URL("http://134.248.80.222:4444/wd/hub"),dc);
					
				}
				
				else if(location.equals("cloud"))
				{
					System.out.println("cloud code");
					
					String USERNAME = "";
					String AUTOMATE_KEY = "";
					String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "";

					
					DesiredCapabilities dc = new DesiredCapabilities();
					System.getProperties().put("", "");
					System.getProperties().put("", "");
					
					dc.setCapability("browser", "Chrome");
					dc.setCapability("browser_version", "70.0");
					dc.setCapability("os", "Windows");
					dc.setCapability("os_version", "10");
					dc.setCapability("browserstack.debug", "true");
				   
					driver = new RemoteWebDriver(new URL(URL), dc);
				
					
				}
				
				
				
			}
			
			else if(browser.equals("firefox"))
			{
				if(location.equals("local"))
				{
				System.setProperty("webdriver.gecko.driver","src\\test\\resources\\drivers\\geckodriver.exe");
				driver=new FirefoxDriver();
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				}
				
				else if(location.equals("grid"))
				{
					System.out.println("Grid code");
					DesiredCapabilities dc = new DesiredCapabilities();
					dc.setBrowserName("firefox");
					dc.setPlatform(Platform.WIN10);	
					
					driver = new RemoteWebDriver(new URL("http://134.248.80.222:4444/wd/hub"),dc);
				}
				
				else if(location.equals("cloud"))
				{
					System.out.println("cloud code");
					
					String USERNAME = "";
					String AUTOMATE_KEY = "";
					String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "";

					
					DesiredCapabilities dc = new DesiredCapabilities();
					
					dc.setCapability("os", "Windows");
					dc.setCapability("os_version", "10");
					dc.setCapability("browser", "Firefox");
					dc.setCapability("browser_version", "62.0");
					dc.setCapability("browserstack.local", "false");
					dc.setCapability("browserstack.selenium_version", "3.13.0");
					
					dc.setBrowserName("chrome");
					dc.setPlatform(Platform.WIN10);	
					driver = new RemoteWebDriver(new URL(URL), caps);
					
				}
			}
			else if (browser.equals("ie"))
				
				 {
				
					if(location.equals("local"))
					{
					DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
					capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
							true);
					capabilities.setCapability("ignoreZoomSetting", false);
					capabilities.setCapability("nativeEvents", true);
					capabilities.setCapability("disable-popup-blocking", true);
					capabilities.setCapability("enablePersistentHover", true);
					capabilities.setCapability("requireWindowFocus", true);
					capabilities.setCapability("initialBrowserUrl", "");
					//capabilities.setCapability("initialBrowserUrl",
					//		"https://cbpr3test-chevron.cs54.force.com/CBP/cbpCommunitiesLoginPage?");
					System.setProperty("webdriver.ie.driver","src\\test\\resources\\drivers\\IEDriverServer.exe");
	
					InternetExplorerOptions options = new InternetExplorerOptions()
							.introduceFlakinessByIgnoringSecurityDomains().ignoreZoomSettings().merge(capabilities)
							.requireWindowFocus();
	
					driver = new InternetExplorerDriver(options);
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					}
					
					else if (location.equals("grid"))
					{
						System.out.println("Grid code");
						DesiredCapabilities dc = new DesiredCapabilities();
						dc.setBrowserName("ie");
						dc.setPlatform(Platform.WIN10);	
						
						driver = new RemoteWebDriver(new URL(""),dc);
					}
	
					else if(location.equals("cloud"))
					{
						System.out.println("cloud code");
						
						String USERNAME = "";
						String AUTOMATE_KEY = "";
						String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "";
						
						
						DesiredCapabilities dc = new DesiredCapabilities();
						
						dc.setCapability("os", "Windows");
						dc.setCapability("os_version", "10");
						dc.setCapability("browser", "IE");
						dc.setCapability("browser_version", "11.0");
						dc.setCapability("browserstack.local", "false");
						dc.setCapability("browserstack.selenium_version", "3.13.0");
						System.getProperties().put("", "");
						System.getProperties().put("", "");
						driver = new RemoteWebDriver(new URL(URL), caps);
						
					}
				}
		}
		
		else if(experience.equals("mobile"))
		{
			System.out.println("in mobile");
			if (platform.equalsIgnoreCase("android"))
			{
			   
			    caps.setCapability("browserName", "android");
			    caps.setCapability("device", androiddevice);
			    caps.setCapability("realMobile", "true");
			    caps.setCapability("os_version", androidversion);
			}
			
			else if (platform.equalsIgnoreCase("ios"))
			{
				System.out.println("in ios method");

				caps.setCapability("os_version", iosversion);
			    caps.setCapability("device",iosdevice);
			    caps.setCapability("real_mobile", "true");
			    caps.setCapability("browserstack.local", "false");
			}
			System.out.println("CAPS is"+caps);
			System.out.println("url is"+BROWSERSTACKURL);

			driver = new RemoteWebDriver(new URL(BROWSERSTACKURL), caps);
			System.out.println("driver is"+driver);
			
		}
		System.out.println("driver before returning is"+driver);
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
		return driver;
	}
	
}
	

