package MashreqBankTestCases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Properties;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import BrowserSetup.BaseCode;
import Helpers.UtilityFiles;
import MashreqBankPageObject.HomepageMashreqBankObjectRepository;

public class HomepageMashreqBankTest extends BaseCode
{

	HomepageMashreqBankObjectRepository Login;
	UtilityFiles util;
	
	
	@Parameters({"browser","execloc"})
	@BeforeMethod
	public void HomePageNavigation(Method method,@Optional("default") String browser,@Optional("default") String execloc) throws Throwable
	{
		String current = System.getProperty("user.dir");
        System.out.println("Current working directory in Java : " + current);
        
		File file = new File(System.getProperty("user.dir") + "\\util\\Variables.properties");
		  
		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();
		
		//load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		System.out.println("Test Executing is: " + method.getName());
		System.out.println("browser  is: " + browser);
		System.out.println("exec location  is: " + execloc);

		driver=initializeDriver(browser,execloc);
		driver.get(MashreqBankUrl);

		if (execloc.equals("desktop"))
		driver.manage().window().maximize();
		
	}
	
	
	@Test (priority=0,groups = {"TCID 400: Verify Items display"}, enabled=true)
	public void VerifyItemsdisplay() throws InterruptedException
	{
		Login = new HomepageMashreqBankObjectRepository(driver);
		Login.getItemsdisplay();
		Login.getScrollToMashreqNews();
		String MashreqNews = Login.getMashreqNews().getText();
		System.out.println("Mashreq News displays as: " + MashreqNews);
	
		Login.getScrollToContactUs();
		Login.getContactUsLink().click();
		Login.ScrollDown("scroll(0,500)");
		
		Login.getSubmitButton().click();
		Login.getScrollToStatusTracker();
		
		
	//	Login.getReachoutforproduct();
		Login.SelectDropdown(3, Login.getreachoutforproduct());
		
		Login.SelectDropdown(0, Login.getComplaintServiceInquiry());
		Login.SelectDropdown(1, Login.getProductSelection());
		Login.SelectDropdown(6, Login.getSubProductSelection());
		
		Login.getMobileNumber().sendKeys("345697");
		String MobileNumberErrorMessage = Login.getMobileNumberErrorMessage().getText();
		System.out.println("Mobile Number Error Message displays as: " + MobileNumberErrorMessage);
		
		Login.getMobileNumber().clear();
		Login.getMobileNumber().sendKeys("3456997");
		Login.getSubmitButton().click();
		
	//	Login.getTextFieldValidation();
		
		Login.LoadTime();
		Login.LoadTime();
		Login.WaitTillPageLoad();
		driver.close();
		
	}
}
